(function(){
	//全局变量定义：
		var layer,
		form;
		layui.use(["form", ], function() {
			layerTips = parent.layer === undefined ? layui.layer : parent.layer; //获取父窗口的layer对象
			layer = layui.layer; //获取当前窗口的layer对象
			form = layui.form;
			layer.ready(function(){
				iEvent.init();
				iView.init();
			})
		});	
	//view方法：
	var iView = {
		init:function(){
			
		},
		
		function1:function(){
			
		},
		function2:function(){
			
		},
	};
	//event方法：
	var iEvent = {
		init:function(){
			
		},
		function1:function(){
			
		},
		function2:function(){
			
		},
		
	};
}());
