var deviceStatus = {
	"slotId2": {
		"slotId": "2",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId3": {
		"slotId": "3",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId4": {
		"slotId": "4",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId5": {
		"slotId": "5",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId38": {
		"slotId": "38",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId39": {
		"slotId": "39",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId40": {
		"slotId": "40",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId41": {
		"slotId": "41",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId42": {
		"slotId": "42",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId43": {
		"slotId": "43",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId44": {
		"slotId": "44",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
}