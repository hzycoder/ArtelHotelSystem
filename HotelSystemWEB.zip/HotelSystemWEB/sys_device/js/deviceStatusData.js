var deviceStatus = {
	"slotId6": {
		"slotId": "6",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId7": {
		"slotId": "7",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId8": {
		"slotId": "8",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId9": {
		"slotId": "9",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId10": {
		"slotId": "10",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId39": {
		"slotId": "39",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId40": {
		"slotId": "40",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId41": {
		"slotId": "41",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId42": {
		"slotId": "42",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId43": {
		"slotId": "43",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
	"slotId44": {
		"slotId": "44",
		"isRoomLightOn": true,
		"lockStatus": "0010",
		"isChildDeviceRegister": "111",
		"isChildDeviceOnline": "101"
	},
}