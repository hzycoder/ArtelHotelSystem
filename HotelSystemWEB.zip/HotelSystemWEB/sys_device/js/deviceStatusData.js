var deviceStatus = [{
		"soltId": "1",
		"soltStatus": "1000"
	}, {
		"soltId": "2",
		"soltStatus": "1111"
	}, {
		"soltId": "3",
		"soltStatus": "1010"
	}, {
		"soltId": "4",
		"soltStatus": "1100"
	},
	{
		"soltId": "5",
		"soltStatus": "1100"
	},
	{
		"soltId": "32",
		"soltStatus": "1100"
	},
	{
		"soltId": "33",
		"soltStatus": "1100"
	},
	{
		"soltId": "34",
		"soltStatus": "1100"
	},
	{
		"soltId": "35",
		"soltStatus": "1100"
	}
];

// {
//	"1": "1000",
//	"2": "1111",
//	"3": "1010",
//	"4": "1100",
//}