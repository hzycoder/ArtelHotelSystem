function config() {
	//		this.URL = "http://192.168.0.107:8080/HotelSystemServer/";
	//		this.WS_URL = "192.168.0.107:8080/HotelSystemServer/websocket";
	//		this.URL = "http://localhost:8080/HotelSystemServer/";
	//		this.WS_URL = "localhost:8080/HotelSystemServer/websocket";
	this.URL = "http://47.106.99.219/HotelSystemServer";
	this.WS_URL = "47.106.99.219/HotelSystemServer/websocket";
}
var CONFIG = new config();