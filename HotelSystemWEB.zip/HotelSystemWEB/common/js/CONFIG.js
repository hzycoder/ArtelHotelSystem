function config() {
	//		this.URL = "http://192.168.0.106:8080/HotelSystemServer/";
	//		this.WS_URL = "192.168.0.106:8080/HotelSystemServer/websocket";
	this.URL = "http://39.108.233.97:8080/HotelSystemServer";
	this.WS_URL = "39.108.233.97:8080/HotelSystemServer/websocket";
}
var CONFIG = new config();