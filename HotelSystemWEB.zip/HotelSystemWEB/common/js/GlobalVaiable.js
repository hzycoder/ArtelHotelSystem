var GlobalUserData = {
	"permission": {
		"1": "酒店管理员",
		"0": "最高管理员"
	}
}